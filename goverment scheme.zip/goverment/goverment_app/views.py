from django.contrib import messages
from django.shortcuts import render, redirect
from goverment_app.models import registertable, policytable, aadharcardtable, contacttable, applicationtable,feedback


def aboutpage(request):
    return render(request, 'about.html')


def signUpPage(request):
    return render(request, 'signup.html')




def addData(request):
    if request.method == 'POST':
        aadhar = request.POST.get('aadhar')
        firstname = request.POST.get('first_name')
        middlename = request.POST.get('middle_name')
        lastname = request.POST.get('last_name')
        phone_no = request.POST.get('phone_no')
        age = request.POST.get('age')
        gender = request.POST.get('gender')
        cast = request.POST.get('cast')
        disabilityStatus = request.POST.get('disabilityStatus')
        minorityStatus = request.POST.get('minorityStatus')
        BPLStatus = request.POST.get('BPLStatus')
        ResidenceArea = request.POST.get('ResidenceArea')

        query = aadharcardtable(aadharnumber=aadhar,firstname=firstname, middlename=middlename, lastname=lastname, phonenumber=phone_no,
                                dob=age, gender=gender, cast=cast, DisabilityStatus=disabilityStatus,
                                MinorityStatus=minorityStatus, BPLStatus=BPLStatus, ResidenceArea=ResidenceArea)
        query.save()
        messages.success(request, 'AADHAR DETAILS ADDED SUCCESSFULLY!!')
    else:
        pass

    return render(request, 'addDetail.html')


def feedback1(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        queue = contacttable(name=name, email=email, subject=subject, feedbackdesk=message)
        queue.save()
        messages.success(request, 'ADDED SUCCESSFULLY!!')

    else:
        pass
    return render(request, 'contact.html')


def fetchdata(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        email = request.POST.get("email")
        occup = request.POST.get("occupation")
        password = request.POST.get("con_password")
        mobile_no = request.POST.get("phone_no")
        occupation = occup.title()
        query = registertable(Full_Name=name, Email=email, Occupation=occupation, Password=password,
                              Mobile_no=mobile_no,status=1, role=0)
        query.save()
        messages.success(request, 'YOU ARE REGISTERED NOW ')

    else:
        messages.error(request, "error")

    return render(request, "index.html")


def loginpage(request):
    return render(request, 'login.html')


def addDetailpage(request):
    return render(request, 'addDetail.html')


def checklogin(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        print(email)
        try:
            check = registertable.objects.get(Email=email, Password=password)
            request.session['loginid'] = check.id
            request.session['loginname'] = check.Full_Name

        except:
            check = None

        if check and check.id is not None:
            return render(request, "index.html")
        else:
            return render(request, "login.html")

    else:
        pass

    return render(request, 'login.html')


def contactpage(request):
    return render(request, 'contact.html')


def indexpage(request):
    query = policytable.objects.all()
    agri=policytable.objects.filter(policytype='Agriculture')
    edu=policytable.objects.filter(policytype='Education')
    health=policytable.objects.filter(policytype__icontains='Health')
    fin=policytable.objects.filter(policytype='Finance')
    counter1=agri.count
    counter2=edu.count
    counter3=fin.count
    counter4=health.count
    details = {
        'data': query,
        'counter1':counter1,
        'counter2': counter2,
        'counter3': counter3,
        'counter4': counter4,

    }
    return render(request, 'index.html', details)


def detailpage(request, id):
    query = policytable.objects.get(id=id)
    details = {
        'data': query
    }
    return render(request, 'detail.html', details)


def schemespage(request):
    query = policytable.objects.all()
    details = {
        'data': query
    }
    return render(request, 'schemes.html', details)


def featurepage(request):
    return render(request, 'feature.html')


def teampage(request):
    return render(request, 'team.html')


def testimonialpage(request):
    return render(request, 'testimonial.html')


def logout(request):
    try:
        del request.session['loginid']
        del request.session['loginname']

    except:
        print("jdsgjbf")
        pass
    return redirect(indexpage)

def applypolicy(request):
    if request.method == 'POST':
      policyid = request.POST.get("applyid")
      regid = request.POST.get("regid")
      name=registertable.objects.filter(id=regid).values("Full_Name")
      query = applicationtable(regid=registertable(id=regid),name=name, policyid=policytable(id=policyid), status=1)
      query.save()
      messages.success(request, 'Data Inserted Successfully')
      # return render(request, 'viewpolicy.html')
    else:
      messages.error(request, 'error occured')
    return redirect(viewpolicy)
def viewpolicy(request):
  uid = request.session['loginid']
  # print(uid)
  apply = applicationtable.objects.filter(regid=uid)
  contex = {
      'apply': apply
    }
  return render(request, 'viewpolicy.html', contex)
def releventpolicy(request):
  uid = request.session['loginid']
  ocuu = registertable.objects.filter(id=uid).values('Occupation')
  print(ocuu)
  me = policytable.objects.filter(policytype__in=ocuu)
  contex = {
    'data': me
  }
  return render(request, 'releventpolicy.html', contex)
#
def feedback2(request):
    if request.method=='POST':
        uid = request.session['loginid']
        rating = request.POST.get("rating")
        comment = request.POST.get("comment")
        query = feedback(regid=registertable(id=uid), rating=rating, comments=comment)
        query.save()
        messages.success(request, 'Feeback submitted successfully!')
    else:
        pass
        # messages.error(request, 'error occured')
    return render(request,'feedback.html')